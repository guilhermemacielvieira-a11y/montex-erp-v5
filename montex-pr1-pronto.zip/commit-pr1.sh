#!/usr/bin/env bash
# ============================================================
# COMMIT PR#1 — montex-erp-v5 (key já rotacionada ✅)
# Rodar na RAIZ do repo. Patch ao lado ou caminho como argumento.
#   ./commit-pr1.sh [caminho/do/montex-pr1-refactor.patch]
# ============================================================
set -euo pipefail
PATCH="${1:-montex-pr1-refactor.patch}"
BRANCH="claude/mobile-app-structure-analysis-psdXa"
PROJECT_REF="trxbohjcwsogthabairh"

echo "==> 1/5  Branch + patch"
git fetch origin
git checkout "$BRANCH"
git pull --ff-only origin "$BRANCH" || true
git apply --check "$PATCH"
git apply "$PATCH"

echo "==> 2/5  Build de verificação"
npm install
npm run build
npm run lint || echo "⚠️  lint com avisos (não bloqueia)"

echo "==> 3/5  Commit + push (Vercel deploya automático)"
git add -A
git commit -m "fix: hardening de segurança + correções do review (push, RLS, datas, scanner)"
git push origin "$BRANCH"

echo "==> 4/5  Supabase: migração + secret + functions"
supabase link --project-ref "$PROJECT_REF" 2>/dev/null || true
supabase db push
PUSH_KEY="$(openssl rand -hex 32)"
supabase secrets set PUSH_API_KEY="$PUSH_KEY"
supabase functions deploy send-push --no-verify-jwt
supabase functions deploy notify-pending --no-verify-jwt

echo "==> 5/5  Concluído ✅"
echo ""
echo "🔑 PUSH_API_KEY (usar no header x-push-key do cron):"
echo "   $PUSH_KEY"
echo ""
echo "Restam só 2 conferências:"
echo " • cron do notify-pending com header x-push-key acima"
echo " • Vercel: remover VITE_SUPABASE_SERVICE_KEY das envs de Production"
