#!/usr/bin/env bash
# ============================================================
# COMMIT PR#1 — montex-erp-v5 (versão GitHub Codespaces / iPhone)
# Rodar na RAIZ do repo dentro do Codespace.
#   ./pr1-temp/commit-pr1-codespaces.sh
# ============================================================
set -euo pipefail
PATCH="${1:-pr1-temp/montex-pr1-refactor.patch}"
BRANCH="claude/mobile-app-structure-analysis-psdXa"
PROJECT_REF="trxbohjcwsogthabairh"

echo "==> 0/6  Supabase CLI (local, sem instalação global)"
if ! npx --yes supabase --version >/dev/null 2>&1; then
  npm i -D supabase
fi
SB="npx supabase"

echo "==> 1/6  Login no Supabase (abre página p/ autorizar — siga o link)"
$SB projects list >/dev/null 2>&1 || $SB login

echo "==> 2/6  Branch + patch"
git fetch origin
git checkout "$BRANCH" 2>/dev/null || git checkout -b "$BRANCH" "origin/$BRANCH"
git pull --ff-only origin "$BRANCH" || true
git apply --check "$PATCH"
git apply "$PATCH"

echo "==> 3/6  Build de verificação"
npm install
npm run build
npm run lint || echo "⚠️  lint com avisos (não bloqueia)"

echo "==> 4/6  Commit + push (Vercel deploya automático)"
git add -A
# evita commitar o zip/pasta temporária e deps
git reset -q pr1-temp 2>/dev/null || true
git reset -q montex-pr1-pronto.zip 2>/dev/null || true
git commit -m "fix: hardening de segurança + correções do review (push, RLS, datas, scanner)"
git push origin "$BRANCH"

echo "==> 5/6  Supabase: migração + secret + functions"
$SB link --project-ref "$PROJECT_REF"
$SB db push
PUSH_KEY="$(openssl rand -hex 32)"
$SB secrets set PUSH_API_KEY="$PUSH_KEY"
$SB functions deploy send-push --no-verify-jwt
$SB functions deploy notify-pending --no-verify-jwt

echo "==> 6/6  Concluído ✅"
echo ""
echo "🔑 PUSH_API_KEY (usar no header x-push-key do cron):"
echo "   $PUSH_KEY"
echo ""
echo "Restam só 2 conferências:"
echo " • cron do notify-pending com header x-push-key acima"
echo " • Vercel: remover VITE_SUPABASE_SERVICE_KEY das envs de Production"
