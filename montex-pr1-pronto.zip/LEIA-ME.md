# Refactor PR #1 — montex-erp-v5 (nível sênior, pronto p/ commit)

13 arquivos · +497/−125 · sintaxe validada (esbuild) em todos os .jsx/.js/.ts

## Como aplicar (escolha UMA via)

**Via A — patch (recomendado):**
```bash
git checkout claude/mobile-app-structure-analysis-psdXa
git apply montex-pr1-refactor.patch
git add -A && git commit -m "fix: hardening de segurança + correções do review (push, RLS, datas, scanner)"
git push
```

**Via B — copiar arquivos:** a pasta `files/` espelha a estrutura do repo;
copie por cima e commit.

## O que mudou (resumo por arquivo)

### 🔴 Segurança
| Arquivo | Mudança |
|---|---|
| `src/api/supabaseClient.js` | **Service_role key removida do bundle.** Só aceita `VITE_SUPABASE_SERVICE_KEY` em `import.meta.env.DEV`; em produção é sempre `null` (módulos caem no cliente anon/RLS). |
| `supabase/migrations/20260609_push_infra_secure.sql` | `device_tokens` com coluna `enabled` + RLS correta (cliente: só INSERT/UPDATE; sem SELECT/DELETE) + tabela `notification_log` p/ idempotência do cron. |
| `supabase/functions/_shared/apns.ts` | `requireApiKey()` — todo endpoint exige header `x-push-key` (secret `PUSH_API_KEY`); comparação em tempo constante. Tratamento de status APNs (410/BadDeviceToken desativa token; 429/5xx logados) + `error` dos selects propagado. |
| `supabase/functions/send-push/index.ts` | Gate `x-push-key` (endpoint era público = vetor de push-spam/phishing). Valida `body` obrigatório. |

### 🟠 Bugs corrigidos
| Arquivo | Mudança |
|---|---|
| `supabase/functions/_shared/pendencias.ts` (novo) | Fonte única server-side espelhando `notificacoes.js`: medições agora **excluem 'cancelado'**; `NULL` status conta como pendente (igual ao app); paginação >1000 linhas (PostgREST trunca em 1000); data em **America/Sao_Paulo**. |
| `supabase/functions/notify-pending/index.ts` | Usa `pendencias.ts`; **idempotência real** via `notification_log` (cron duplicado não repete push; `{"force":true}` para reenvio); gate `x-push-key`. |
| `src/mobile/ui/push.js` | Corrige corrida de boot: token que chega antes do e-mail fica em `pendingToken` e é reconciliado via `setPushUser()` (antes gravava `user_email NULL` → push nunca chegava). `removePush()` agora marca `enabled=false` (RLS não permite DELETE) e desativa só ESTE device. |
| `src/mobile/ui/notificacoes.js` | Bug de fuso: `toISOString()` é UTC — entre 21h e 00h BRT despesas de hoje viravam "vencidas". Agora data local. |
| `src/mobile/pages/DashboardMobile.jsx` / `HomeMobile.jsx` | Mesmo fix de fuso nas despesas em atraso. |
| `src/mobile/pages/HomeMobile.jsx` | Card "Análise Estratégica" gated por `bi.view` (mesma perm da rota) — operador não cai mais em "Acesso restrito" ao tocar. |
| `src/mobile/ui/deeplinks.js` | `startsWith('/m')` aceitava `/malicious` → agora só `/m` exato ou `/m/...`. `tipo: medicao` → `/m/medicao` (antes ia p/ receitas). |

### 🟡 Qualidade/performance
| Arquivo | Mudança |
|---|---|
| `src/mobile/ui/Scanner.jsx` | `onResult`/`continuous` lidos via ref (elimina closure stale se a tela recriar o handler com scanner aberto). Throttle do loop web: detecção 8x/s em vez de 60fps (bateria). |
| `src/mobile/pages/DashboardMobile.jsx` | `rankObras` em passada única O(P+O) (era O(obras×peças)). KPI "Margem do contrato" renomeado p/ **"Resultado projetado"** (o cálculo é receitas−despesas totais, não margem sobre contrato). |
| `MOBILE-IOS-SETUP.md` | §7.1 aponta p/ a migração segura; secrets incluem `PUSH_API_KEY`; cron com header `x-push-key` + nota de idempotência. |

## ⚠️ Ações manuais OBRIGATÓRIAS (fora do código)

1. ~~REVOGAR a service_role key~~ ✅ **JÁ RESOLVIDO** (key rotacionada).
2. Rodar a migração: `supabase db push` (ou colar o SQL no editor).
   Se a policy antiga `"device_tokens upsert"` já foi criada, a migração
   a remove (`drop policy if exists`).
3. `supabase secrets set PUSH_API_KEY="$(openssl rand -hex 32)"` e usar o
   mesmo valor no cron e em qualquer chamada manual ao send-push.
4. Redeploy: `supabase functions deploy send-push notify-pending --no-verify-jwt`.
5. Verificar se a tabela de perfis usada por `resolveTokens` é mesmo
   `user_profiles(email, role)` — se o nome divergir, ajustar em
   `_shared/apns.ts` (agora o erro aparece no log em vez de falhar mudo).
6. `npm install` + `npm run build` + `npm run lint` (deps Capacitor novas
   do PR continuam pendentes de instalação local).

## Pendências conscientes (não tratadas aqui)
- A autorização real continua client-side (`Protected`/`hasPermission` são
  UX, não segurança). Com a service_role fora do front, o próximo passo
  estrutural é **RLS por papel** nas tabelas sensíveis (financeiro,
  orçamentos) amarrada ao auth do Supabase — mudança maior, fora do escopo
  deste PR.
- `loadConcluidasSmart` dentro de `useState` inicializador roda 2× em
  StrictMode; vale migrar p/ `useEffect` num PR próprio (toca montagemSync).
