// ============================================================
// EDGE FUNCTION — notify-pending (push automático via cron)
// ============================================================
// Varre as pendências (regras em ../_shared/pendencias.ts, espelho de
// src/mobile/ui/notificacoes.js) e dispara push aos papéis
// responsáveis, com `to` apontando para a tela que resolve (deep link).
//
// Segurança: deployada com --no-verify-jwt → exige header
//   x-push-key: <PUSH_API_KEY>   (secret da função)
//
// Idempotência REAL: cada alerta grava (alert_key, dia) em
// notification_log com `on conflict do nothing`; só envia quando o
// insert "pegou" a chave. Cron duplicado / retry do pg_net / invocação
// manual no mesmo dia NÃO repetem o push. Para forçar reenvio:
//   { "force": true } no body.
//
// Deploy: supabase functions deploy notify-pending --no-verify-jwt
// Agendamento pg_cron: ver MOBILE-IOS-SETUP.md §7.5 (incluir o header).
// ============================================================
import { adminClient, requireApiKey, sendPush } from '../_shared/apns.ts';
import { coletarPendencias, hojeBRT } from '../_shared/pendencias.ts';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-push-key',
};
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...CORS, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  const denied = requireApiKey(req);
  if (denied) return denied;

  try {
    const { force = false } = await req.json().catch(() => ({}));
    const admin = adminClient();
    const dia = hojeBRT();
    const alerts = await coletarPendencias(admin);

    const out: unknown[] = [];
    for (const a of alerts) {
      // Trava de idempotência: só envia se for o primeiro do dia p/ esta chave
      if (!force) {
        const { data: claimed, error } = await admin
          .from('notification_log')
          .insert({ alert_key: a.key, dia, payload: { title: a.title, body: a.body, to: a.to } })
          .select('alert_key');
        if (error && error.code !== '23505') throw new Error(`notification_log: ${error.message}`);
        if (!claimed?.length) { out.push({ key: a.key, skipped: 'já enviado hoje' }); continue; }
      }
      const r = await sendPush({ title: a.title, body: a.body, to: a.to, target: { roles: a.roles }, admin });
      out.push({ key: a.key, title: a.title, roles: a.roles, ...r });
    }
    return json({ dia, alerts: alerts.length, detail: out });
  } catch (e) {
    console.error('[notify-pending]', e);
    return json({ error: String((e as Error)?.message || e) }, 500);
  }
});
