// ============================================================
// _shared/apns.ts — envio APNs reutilizável (hardened)
// ============================================================
// Usado por send-push (sob demanda) e notify-pending (cron). Concentra
// JWT ES256 (.p8), resolução de tokens-alvo e o POST ao APNs.
//
// Mudanças desta revisão:
//  * requireApiKey(): as funções são deployadas com --no-verify-jwt,
//    então TODO endpoint exige o header `x-push-key` == PUSH_API_KEY
//    (secret). Sem isso, qualquer pessoa na internet enviaria push
//    arbitrário (spam/phishing) a todos os usuários.
//  * resolveTokens(): trata `error` dos selects (antes falhava em
//    silêncio → cron "funcionava" sem nunca enviar) e filtra enabled.
//  * sendPush(): trata status por classe — 410/400 BadDeviceToken
//    desativa o token; 429/5xx são logados (observabilidade); demais
//    erros logados com reason do APNs.
// ============================================================
import { createClient, SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2';

const enc = new TextEncoder();
const b64url = (buf: ArrayBuffer | Uint8Array) => {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = ''; for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};

export function adminClient(): SupabaseClient {
  return createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
}

// Gate de autenticação das funções públicas (--no-verify-jwt).
// Retorna null se autorizado; Response 401/500 caso contrário.
export function requireApiKey(req: Request): Response | null {
  const expected = Deno.env.get('PUSH_API_KEY');
  if (!expected) {
    console.error('[apns] PUSH_API_KEY não configurada — bloqueando por segurança');
    return new Response(JSON.stringify({ error: 'PUSH_API_KEY não configurada no servidor' }), {
      status: 500, headers: { 'Content-Type': 'application/json' },
    });
  }
  const got = req.headers.get('x-push-key') || '';
  // Comparação em tempo constante (evita timing attack trivial)
  const a = enc.encode(got), b = enc.encode(expected);
  let diff = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) diff |= (a[i] ?? 0) ^ (b[i] ?? 0);
  if (diff !== 0) {
    return new Response(JSON.stringify({ error: 'unauthorized' }), {
      status: 401, headers: { 'Content-Type': 'application/json' },
    });
  }
  return null;
}

async function importKey(pem: string): Promise<CryptoKey> {
  const body = pem.replace(/-----BEGIN PRIVATE KEY-----/, '').replace(/-----END PRIVATE KEY-----/, '').replace(/\s+/g, '');
  const der = Uint8Array.from(atob(body), c => c.charCodeAt(0));
  return crypto.subtle.importKey('pkcs8', der, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
}

// JWT APNs válido por ~50min (Apple exige refresh entre 20–60min) — cacheado.
let jwtCache: { token: string; t: number } | null = null;
async function getJwt(): Promise<string> {
  if (jwtCache && Date.now() - jwtCache.t < 50 * 60 * 1000) return jwtCache.token;
  const KEY_ID = Deno.env.get('APNS_KEY_ID')!;
  const TEAM_ID = Deno.env.get('APNS_TEAM_ID')!;
  const key = await importKey(Deno.env.get('APNS_PRIVATE_KEY')!);
  const header = b64url(enc.encode(JSON.stringify({ alg: 'ES256', kid: KEY_ID })));
  const payload = b64url(enc.encode(JSON.stringify({ iss: TEAM_ID, iat: Math.floor(Date.now() / 1000) })));
  const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, enc.encode(`${header}.${payload}`));
  const token = `${header}.${payload}.${b64url(sig)}`;
  jwtCache = { token, t: Date.now() };
  return token;
}

export type Target = { tokens?: string[]; email?: string; role?: string; roles?: string[] };

// Resolve a lista de tokens iOS ativos a partir do alvo.
// Lança erro em falha de query (não falha em silêncio).
export async function resolveTokens(admin: SupabaseClient, target: Target = {}): Promise<string[]> {
  if (Array.isArray(target.tokens) && target.tokens.length) return target.tokens;

  let emails: string[] | null = null;
  const roles = target.roles || (target.role ? [target.role] : null);
  if (roles) {
    const { data, error } = await admin.from('user_profiles').select('email').in('role', roles);
    if (error) throw new Error(`resolveTokens/user_profiles: ${error.message}`);
    emails = (data || []).map((p: { email: string }) => p.email).filter(Boolean);
    if (!emails.length) {
      console.warn(`[apns] nenhum usuário com role ${JSON.stringify(roles)} em user_profiles`);
      return [];
    }
  } else if (target.email) {
    emails = [target.email];
  }

  let q = admin.from('device_tokens').select('token').eq('platform', 'ios').eq('enabled', true);
  if (emails) q = q.in('user_email', emails);
  const { data: rows, error } = await q;
  if (error) throw new Error(`resolveTokens/device_tokens: ${error.message}`);
  return (rows || []).map((r: { token: string }) => r.token);
}

type SendResult = { sent: number; total: number; failed: number; invalidated: number };

// Envia uma push (data:{ to }) para o alvo. Desativa tokens inválidos.
export async function sendPush(opts: { title: string; body: string; to?: unknown; target?: Target; admin?: SupabaseClient }): Promise<SendResult> {
  const admin = opts.admin || adminClient();
  const tokens = await resolveTokens(admin, opts.target || {});
  if (!tokens.length) return { sent: 0, total: 0, failed: 0, invalidated: 0 };

  const HOST = Deno.env.get('APNS_HOST') || 'api.push.apple.com';
  const BUNDLE_ID = Deno.env.get('APNS_BUNDLE_ID')!;
  const jwt = await getJwt();
  const apnsBody = JSON.stringify({
    aps: { alert: { title: opts.title, body: opts.body }, sound: 'default', 'mutable-content': 1 },
    to: opts.to ?? '',
  });

  let invalidated = 0;
  const results = await Promise.allSettled(tokens.map(async (tk) => {
    const res = await fetch(`https://${HOST}/3/device/${tk}`, {
      method: 'POST',
      headers: {
        authorization: `bearer ${jwt}`, 'apns-topic': BUNDLE_ID,
        'apns-push-type': 'alert', 'apns-priority': '10', 'content-type': 'application/json',
      },
      body: apnsBody,
    });
    if (res.status === 200) return 200;

    // Diagnóstico: APNs devolve { reason } no corpo do erro
    let reason = '';
    try { reason = (await res.json())?.reason || ''; } catch { /* corpo vazio */ }

    if (res.status === 410 || (res.status === 400 && reason === 'BadDeviceToken')) {
      // Token morto/inválido → desativa (não DELETE: mantém auditoria)
      await admin.from('device_tokens').update({ enabled: false, updated_at: new Date().toISOString() }).eq('token', tk);
      invalidated++;
    } else {
      // 429 TooManyRequests, 403 (JWT/topic), 5xx — visível no log da função
      console.warn(`[apns] envio falhou: status=${res.status} reason=${reason} token=…${tk.slice(-8)}`);
    }
    return res.status;
  }));

  const sent = results.filter(r => r.status === 'fulfilled' && r.value === 200).length;
  for (const r of results) if (r.status === 'rejected') console.warn('[apns] fetch rejeitado:', r.reason);
  return { sent, total: tokens.length, failed: tokens.length - sent, invalidated };
}
