// ============================================================
// _shared/pendencias.ts — predicados de pendência (fonte única server)
// ============================================================
// Espelha src/mobile/ui/notificacoes.js no servidor com os MESMOS
// critérios de negócio (a versão anterior divergia: incluía medições
// canceladas e usava data UTC). Qualquer ajuste de regra deve ser
// feito AQUI e em notificacoes.js em conjunto — os dois arquivos têm
// um comentário cruzado apontando um para o outro.
//
// Correções desta revisão:
//  * Medições: exclui status 'cancelado' (alinha com o app).
//  * "Hoje" calculado em America/Sao_Paulo (toISOString é UTC: entre
//    21h e 00h BRT o dia virava e despesas de hoje apareciam vencidas).
//  * Paginação: PostgREST limita 1000 linhas por resposta; estoque e
//    despesas agora paginam (a versão anterior silenciosamente
//    ignorava tudo acima de 1000).
//  * error dos selects propagado (nada de falha silenciosa).
// ============================================================
import { SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2';

export const num = (v: unknown) => Number(v) || 0;
export const money = (n: number) =>
  'R$ ' + num(n).toLocaleString('pt-BR', { maximumFractionDigits: 0 });

// Data de "hoje" no fuso de operação (BRT), formato YYYY-MM-DD.
export function hojeBRT(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(new Date()); // en-CA → YYYY-MM-DD
}

// SELECT paginado (PostgREST devolve no máx. 1000 linhas por página).
async function selectAll<T>(build: (from: number, to: number) => PromiseLike<{ data: T[] | null; error: { message: string } | null }>, label: string): Promise<T[]> {
  const PAGE = 1000;
  const out: T[] = [];
  for (let from = 0; ; from += PAGE) {
    const { data, error } = await build(from, from + PAGE - 1);
    if (error) throw new Error(`${label}: ${error.message}`);
    if (!data?.length) break;
    out.push(...data);
    if (data.length < PAGE) break;
  }
  return out;
}

export type Alerta = { key: string; title: string; body: string; to: string; roles: string[] };

const GESTAO = ['gerente', 'admin'];
const FIN = ['gerente', 'financeiro', 'admin'];
const OPER = ['gerente', 'supervisor', 'admin'];

// Varre as pendências e devolve a lista de alertas do dia.
export async function coletarPendencias(admin: SupabaseClient): Promise<Alerta[]> {
  const hoje = hojeBRT();
  const alerts: Alerta[] = [];

  // 1) Despesas vencidas — mesmos critérios do app:
  //    status ∉ {pago, cancelado} (NULL conta como pendente) e venc < hoje
  type Desp = { valor: unknown; status: string | null };
  const desp = await selectAll<Desp>(
    (from, to) => admin.from('lancamentos_despesas')
      .select('valor, status')
      .or('status.is.null,and(status.neq.pago,status.neq.cancelado)')
      .lt('data_vencimento', hoje)
      .range(from, to),
    'pendencias/despesas',
  );
  if (desp.length) {
    const total = desp.reduce((s, d) => s + num(d.valor), 0);
    alerts.push({ key: 'despesas-vencidas', title: 'Despesas vencidas', body: `${desp.length} despesa(s) vencida(s) · ${money(total)}`, to: '/m/despesas', roles: FIN });
  }

  // 2) Estoque crítico/zerado (minimo*0.5 não filtra no PostgREST → calcula aqui)
  type Estq = { quantidade: unknown; minimo: unknown };
  const estq = await selectAll<Estq>(
    (from, to) => admin.from('estoque').select('quantidade, minimo').range(from, to),
    'pendencias/estoque',
  );
  const crit = estq.filter(i => { const q = num(i.quantidade), m = num(i.minimo); return q <= 0 || (m > 0 && q <= m * 0.5); });
  if (crit.length) alerts.push({ key: 'estoque-critico', title: 'Estoque crítico', body: `${crit.length} item(ns) zerado(s)/abaixo do mínimo`, to: '/m/estoque', roles: OPER });

  // 3) Fila de embarque — count sem trazer linhas
  const { count: prontas, error: errPecas } = await admin
    .from('pecas_producao').select('id', { count: 'exact', head: true }).eq('etapa', 'expedido');
  if (errPecas) throw new Error(`pendencias/pecas: ${errPecas.message}`);
  if (prontas && prontas > 0) alerts.push({ key: 'fila-embarque', title: 'Fila de embarque', body: `${prontas} conjunto(s) prontos para expedição`, to: '/m/expedicao', roles: OPER });

  // 4) Medições pendentes — exclui pago E cancelado (alinhado ao app)
  type Med = { valor: unknown; status: string | null };
  const med = await selectAll<Med>(
    (from, to) => admin.from('medicoes')
      .select('valor, status')
      .or('status.is.null,and(status.neq.pago,status.neq.cancelado)')
      .range(from, to),
    'pendencias/medicoes',
  );
  if (med.length) {
    const total = med.reduce((s, m) => s + num(m.valor), 0);
    alerts.push({ key: 'medicoes-pendentes', title: 'Medições pendentes', body: `${med.length} medição(ões) · a receber ${money(total)}`, to: '/m/receitas', roles: GESTAO });
  }

  return alerts;
}
