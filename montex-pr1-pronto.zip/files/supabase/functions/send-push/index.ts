// ============================================================
// EDGE FUNCTION — send-push (APNs, sob demanda)
// ============================================================
// Envia uma push iOS para um alvo. O payload inclui `to` no nível
// superior → o app abre direto na rota certa (deeplinks.js).
//
// Segurança: deployada com --no-verify-jwt, portanto EXIGE o header
//   x-push-key: <PUSH_API_KEY>
// Sem esse gate, o endpoint era público: qualquer pessoa podia enviar
// push arbitrário (título/corpo/rota) a TODOS os devices — vetor de
// spam e phishing direto no celular da equipe.
//
// Request (POST, JSON):
//   {
//     "title": "Despesa vencida",
//     "body": "3 despesas venceram — regularize",
//     "to": "/m/despesas",                 // rota interna OU { tipo: "despesa" }
//     "target": { "email": "x@y.com" }     // ou { "role" } / { "roles":[] }
//   }                                      // ou { "tokens":[] } ou {} = todos iOS
//
// Deploy: supabase functions deploy send-push --no-verify-jwt
//   + supabase secrets set PUSH_API_KEY="$(openssl rand -hex 32)"
// ============================================================
import { requireApiKey, sendPush } from '../_shared/apns.ts';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-push-key',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  const denied = requireApiKey(req);
  if (denied) return denied;

  try {
    const { title = 'MONTEX', body = '', to = '', target = {} } = await req.json();
    if (!body) return json({ error: 'body é obrigatório' }, 400);
    const r = await sendPush({ title, body, to, target });
    return json(r);
  } catch (e) {
    console.error('[send-push]', e);
    return json({ error: String((e as Error)?.message || e) }, 500);
  }
});
