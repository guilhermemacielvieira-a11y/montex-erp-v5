-- ============================================================
-- PUSH INFRA (segura) — device_tokens + notification_log
-- ============================================================
-- Substitui a policy permissiva proposta anteriormente
-- (`for all using(true)`), que deixava qualquer cliente com a anon
-- key LER todos os tokens (mapa device→email da empresa inteira) e
-- APAGAR/sobrescrever tokens alheios.
--
-- Modelo:
--   * Cliente (anon key): só INSERT/UPDATE do próprio token.
--     NÃO há policy de SELECT/DELETE → cliente não lê nem apaga nada.
--   * Edge Functions (service_role): leem/limpam tokens livremente
--     (service_role ignora RLS por definição).
--   * Desativar push no app = marcar enabled=false (UPDATE), não DELETE.
-- ============================================================

create table if not exists public.device_tokens (
  token       text primary key,
  user_email  text,
  platform    text not null default 'ios',
  enabled     boolean not null default true,
  updated_at  timestamptz not null default now()
);

create index if not exists device_tokens_email_idx
  on public.device_tokens (user_email) where enabled;

alter table public.device_tokens enable row level security;

-- Remove a policy aberta, se tiver sido criada pela versão anterior do doc
drop policy if exists "device_tokens upsert" on public.device_tokens;

-- Cliente pode registrar um token novo…
drop policy if exists device_tokens_insert on public.device_tokens;
create policy device_tokens_insert on public.device_tokens
  for insert to anon, authenticated
  with check (true);

-- …e atualizar um token EXISTENTE (rotação de token / enable-disable /
-- troca de usuário no mesmo device). Como o PK é o próprio token APNs
-- (opaco, 64+ hex, não enumerável), atualizar exige conhecê-lo.
drop policy if exists device_tokens_update on public.device_tokens;
create policy device_tokens_update on public.device_tokens
  for update to anon, authenticated
  using (true) with check (true);

-- (Sem policy de SELECT nem DELETE para anon/authenticated — de propósito.)

-- ============================================================
-- notification_log — idempotência do notify-pending (cron)
-- ============================================================
-- Garante que o mesmo alerta não dispare 2x no mesmo dia mesmo que o
-- cron rode em duplicidade (retry do pg_net, redeploy, invocação manual).
-- A Edge Function faz INSERT ... on conflict do nothing e só envia
-- quando o insert "pegou" a chave do dia.

create table if not exists public.notification_log (
  alert_key  text not null,                       -- ex.: 'despesas-vencidas'
  dia        date not null default (now() at time zone 'America/Sao_Paulo')::date,
  payload    jsonb,
  created_at timestamptz not null default now(),
  primary key (alert_key, dia)
);

alter table public.notification_log enable row level security;
-- Nenhuma policy: apenas service_role (Edge Functions) acessa.

-- Limpeza opcional (manter 90 dias):
-- delete from public.notification_log where created_at < now() - interval '90 days';
