// ============================================================
// PUSH NOTIFICATIONS (MOBILE) — registro de device + token
// ============================================================
// Acessa @capacitor/push-notifications via runtime (window.Capacitor.
// Plugins.PushNotifications) — SEM import estático — para degradar no
// web/PWA (mesmo padrão de haptics.js / deeplinks.js).
//
// Responsabilidades AQUI: permissão + register() + persistir o token
// APNs/FCM em `device_tokens` (Supabase). O ROTEAMENTO ao tocar a push
// é tratado em deeplinks.js — não duplicamos esse listener aqui.
//
// RLS de device_tokens (migração 20260609_push_infra_secure.sql):
// o cliente só pode INSERT/UPDATE — nunca SELECT/DELETE. Por isso
// "desativar push" = UPDATE enabled=false (não DELETE).
//
// Robustez contra corrida de boot: o evento 'registration' chega de
// forma assíncrona e pode disparar ANTES do AuthContext resolver o
// e-mail (ex.: re-registro no boot). Nesse caso o token fica em
// `pendingToken` e é reconciliado quando setPushUser(email) chegar —
// sem isso o token era gravado com user_email NULL e a resolução por
// e-mail/role nunca encontrava o device (push "fantasma").
// ============================================================
import { supabase } from '@/api/supabaseClient';

function cap() {
  try { return typeof window !== 'undefined' ? window.Capacitor : null; } catch { return null; }
}
function pushPlugin() {
  const c = cap();
  return c?.isNativePlatform?.() && c?.Plugins?.PushNotifications ? c.Plugins.PushNotifications : null;
}
function platform() {
  try { return cap()?.getPlatform?.() || 'web'; } catch { return 'web'; }
}

// Disponível só em build nativo (iOS/Android com o plugin)
export function isPushSupported() { return !!pushPlugin(); }

let listenersReady = false;
let currentEmail = null;
let lastToken = null;     // token deste device nesta sessão (p/ disable pontual)
let pendingToken = null;  // token recebido antes do e-mail estar disponível

// Persiste/atualiza o token do dispositivo para o usuário atual.
async function saveToken(token, { enabled = true } = {}) {
  if (!token) return;
  lastToken = token;
  if (!currentEmail) { pendingToken = token; } // reconcilia em setPushUser
  try {
    await supabase.from('device_tokens').upsert(
      { token, user_email: currentEmail || null, platform: platform(), enabled, updated_at: new Date().toISOString() },
      { onConflict: 'token' }
    );
  } catch (e) {
    console.warn('[push] falha ao salvar token:', e?.message || e);
  }
}

// Informa/atualiza o usuário dono deste device. Chamar no boot (quando o
// AuthContext resolver) e no login. Reconcilia token pendente sem e-mail.
export async function setPushUser(userEmail) {
  if (!userEmail || userEmail === currentEmail) { currentEmail = userEmail || currentEmail; return; }
  currentEmail = userEmail;
  if (pendingToken) { const t = pendingToken; pendingToken = null; await saveToken(t); }
  else if (lastToken) { await saveToken(lastToken); } // troca de usuário no mesmo device
}

function ensureListeners() {
  const Push = pushPlugin();
  if (!Push || listenersReady) return;
  listenersReady = true;
  // Token emitido após register() — pode chegar de forma assíncrona.
  Push.addListener('registration', (t) => saveToken(t?.value));
  Push.addListener('registrationError', (e) => console.warn('[push] registrationError:', e));
  // OBS: pushNotificationActionPerformed (toque → rota) fica em deeplinks.js.
}

// Solicita permissão e registra o device. Retorna { ok, reason }.
export async function registerPush(userEmail) {
  const Push = pushPlugin();
  if (!Push) return { ok: false, reason: 'unsupported' };
  if (userEmail) await setPushUser(userEmail);
  try {
    let perm = await Push.checkPermissions();
    if (perm.receive === 'prompt' || perm.receive === 'prompt-with-rationale') {
      perm = await Push.requestPermissions();
    }
    if (perm.receive !== 'granted') return { ok: false, reason: 'denied' };
    ensureListeners();
    await Push.register();
    return { ok: true };
  } catch (e) {
    console.warn('[push] registerPush falhou:', e?.message || e);
    return { ok: false, reason: 'error' };
  }
}

// Desativa o push DESTE device: marca enabled=false (a RLS não permite
// DELETE pelo cliente — e desativar preserva auditoria). Se o token desta
// sessão não for conhecido (app recém-aberto sem register), não há o que
// desativar localmente — o servidor ignora tokens enabled=false.
export async function removePush() {
  try {
    if (lastToken) await saveToken(lastToken, { enabled: false });
  } catch (e) {
    console.warn('[push] removePush falhou:', e?.message || e);
  }
  return { ok: true };
}
